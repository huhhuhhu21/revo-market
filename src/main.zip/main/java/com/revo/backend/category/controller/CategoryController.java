
package com.revo.backend.category.controller;

import com.revo.backend.category.service.CategoryService;
import com.revo.backend.category.dto.CategoryListResponse;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/categories")
public class CategoryController {

    private final CategoryService categoryService;

    public CategoryController(CategoryService categoryService) {
        this.categoryService = categoryService;
    }

    @GetMapping
    public CategoryListResponse getCategories() {
        return categoryService.getActiveCategories();
    }
}
