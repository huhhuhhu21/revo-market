package com.revo.backend.listing.controller;

import com.revo.backend.listing.dto.*;
import com.revo.backend.listing.service.ListingService;

import org.springframework.web.bind.annotation.*;
import com.revo.backend.listing.dto.ListingDetailResponse;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;

import com.revo.backend.listing.dto.CreateListingRequest;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import java.net.URI;
import tools.jackson.databind.JsonNode;
import org.springframework.http.HttpStatus;

@RestController
@RequestMapping("/api/v1/listings")
public class ListingController {

    private final ListingService listingService;

    public ListingController(ListingService listingService) {
        this.listingService = listingService;
    }

    @GetMapping
    public ListingSearchResponse search(
            @RequestParam(required = false) String page,
            @RequestParam(required = false) String size,
            @RequestParam(required = false) String q,
            @RequestParam(required = false) String categoryId,
            @RequestParam(required = false) String minPrice,
            @RequestParam(required = false) String maxPrice,
            @RequestParam(required = false) String condition,
            @RequestParam(required = false) String province,
            @RequestParam(required = false) String ward
    ) {
        ListingSearchRequest request = new ListingSearchRequest(
                page,
                size,
                q,
                categoryId,
                minPrice,
                maxPrice,
                condition,
                province,
                ward
        );

        return listingService.search(request);
    }

    @GetMapping("/{listingId}")
    public ListingDetailResponse getDetail(
            @PathVariable String listingId,
            @AuthenticationPrincipal Jwt jwt
    ) {
        Long viewerId = jwt == null
                ? null
                : Long.parseLong(jwt.getSubject());

        return listingService.getDetail(
                listingId,
                viewerId
        );
    }

    @PostMapping
    public ResponseEntity<ListingDetailResponse> create(
            @Valid @RequestBody CreateListingRequest request,
            @AuthenticationPrincipal Jwt jwt
    ) {
        Long sellerId = Long.parseLong(jwt.getSubject());

        ListingDetailResponse response =
                listingService.create(sellerId, request);

        URI location = URI.create(
                "/api/v1/listings/" + response.id()
        );

        return ResponseEntity
                .created(location)
                .body(response);
    }

    @PatchMapping("/{listingId}")
    public ListingDetailResponse update(
            @PathVariable String listingId,
            @RequestBody JsonNode request,
            @AuthenticationPrincipal Jwt jwt
    ) {
        Long sellerId = Long.parseLong(jwt.getSubject());

        return listingService.update(
                sellerId,
                listingId,
                request
        );
    }

    @DeleteMapping("/{listingId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(
            @PathVariable String listingId,
            @AuthenticationPrincipal Jwt jwt
    ) {
        Long sellerId = Long.parseLong(jwt.getSubject());

        listingService.delete(
                sellerId,
                listingId
        );
    }


    @PostMapping("/{listingId}/hide")
    public ListingDetailResponse hide(
            @PathVariable String listingId,
            @AuthenticationPrincipal Jwt jwt
    ) {
        Long sellerId = Long.parseLong(
                jwt.getSubject()
        );

        return listingService.hide(
                sellerId,
                listingId
        );
    }

    @PostMapping("/{listingId}/restore")
    public ListingDetailResponse restore(
            @PathVariable String listingId,
            @AuthenticationPrincipal Jwt jwt
    ) {
        Long sellerId = Long.parseLong(
                jwt.getSubject()
        );

        return listingService.restore(
                sellerId,
                listingId
        );
    }

}